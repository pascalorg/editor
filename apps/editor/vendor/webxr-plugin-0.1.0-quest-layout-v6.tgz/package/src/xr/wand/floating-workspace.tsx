'use client'

import { useFrame, useThree, type ThreeEvent } from '@react-three/fiber'
import { isXRInputSourceState, useXR, useXRInputSourceState } from '@react-three/xr'
import { useCallback, useEffect, useRef, useState } from 'react'
import { type Group, Matrix4, type Mesh, Vector3 } from 'three'
import { useWebXRSceneLayers } from '../layers'
import { isQuestYPressed } from '../controller-buttons'
import { useXRPlayerMode } from '../mode-switching/store/player-mode'
import type { XRWandAdapter } from './adapter'
import { XRWandBuildPanel } from './build-panel'
import { XRWandPaintPanel } from './paint-panel'
import { XR_WAND_PANEL_INPUT_NAME } from './panel-layout'
import { useXRWandPanelSettings } from './panel-settings'
import { XRWandSettingsPanel } from './settings-panel'
import { PanelFace, SpatialButton } from './spatial-controls'
import { SpatialLine } from './spatial-line'
import { XR_WAND_THEME } from './theme'
import {
  placeWorkspace,
  workspaceParentPoint,
  WORKSPACE_CONTENT_SCALE,
  WorkspaceDrag,
} from './workspace-placement'
import { useXRWorkspace } from './workspace-store'

type PointerDownEvent = ThreeEvent<PointerEvent>
type WorkspaceTab = 'paint' | 'build' | 'settings'
const TABS = ['paint', 'build', 'settings'] as const

function RailIcon({ kind, selected = false }: { kind: WorkspaceTab | 'center'; selected?: boolean }) {
  const { overlay } = useWebXRSceneLayers()
  const color = selected ? XR_WAND_THEME.accentLine : XR_WAND_THEME.text
  if (kind === 'paint') {
    return (
      <>
        <SpatialLine
          color={color}
          lineWidth={2.4}
          points={[
            [-0.025, -0.025, 0.014],
            [0.026, 0.026, 0.014],
          ]}
        />
        <mesh layers={overlay} position={[-0.031, -0.031, 0.014]} raycast={() => null}>
          <circleGeometry args={[0.014, 3]} />
          <meshBasicMaterial color={color} />
        </mesh>
      </>
    )
  }
  if (kind === 'build') {
    return (
      <SpatialLine
        color={color}
        lineWidth={2}
        points={[
          [0, 0.034, 0.014],
          [0.034, 0.015, 0.014],
          [0.034, -0.024, 0.014],
          [0, -0.043, 0.014],
          [-0.034, -0.024, 0.014],
          [-0.034, 0.015, 0.014],
          [0, 0.034, 0.014],
          [0, -0.006, 0.014],
          [0.034, -0.024, 0.014],
          [0, -0.006, 0.014],
          [-0.034, -0.024, 0.014],
        ]}
      />
    )
  }
  if (kind === 'settings') {
    return (
      <>
        <mesh layers={overlay} position={[0, 0, 0.014]} raycast={() => null}>
          <ringGeometry args={[0.013, 0.025, 18]} />
          <meshBasicMaterial color={color} />
        </mesh>
        {[0, Math.PI / 4, Math.PI / 2, (Math.PI * 3) / 4].map((rotation) => (
          <mesh
            key={rotation}
            layers={overlay}
            position={[0, 0, 0.014]}
            rotation={[0, 0, rotation]}
            raycast={() => null}
          >
            <planeGeometry args={[0.009, 0.072]} />
            <meshBasicMaterial color={color} />
          </mesh>
        ))}
      </>
    )
  }
  return (
    <>
      <mesh layers={overlay} position={[0, 0, 0.014]} raycast={() => null}>
        <ringGeometry args={[0.027, 0.032, 20]} />
        <meshBasicMaterial color={color} />
      </mesh>
      <mesh layers={overlay} position={[0, 0, 0.014]} raycast={() => null}>
        <circleGeometry args={[0.009, 16]} />
        <meshBasicMaterial color={color} />
      </mesh>
    </>
  )
}

function RailButton({
  icon,
  name,
  y,
  selected,
  onClick,
}: {
  icon: WorkspaceTab | 'center'
  name: string
  y: number
  selected?: boolean
  onClick: () => void
}) {
  return (
    <SpatialButton
      name={name}
      onClick={onClick}
      position={[0, y, 0]}
      selected={selected}
      size={[0.115, 0.105]}
    >
      <RailIcon kind={icon} selected={selected} />
    </SpatialButton>
  )
}

export function XRFloatingWorkspace({ adapter }: { adapter: XRWandAdapter }) {
  const root = useRef<Group>(null)
  const handle = useRef<Mesh>(null)
  const camera = useThree((state) => state.camera)
  const session = useXR((state) => state.session)
  const referenceSpace = useXR((state) => state.originReferenceSpace)
  const origin = useXR((state) => state.origin)
  const playerMode = useXRPlayerMode((state) => state.mode)
  const controller = useXRInputSourceState('controller', 'left')
  const { overlay } = useWebXRSceneLayers()
  const panelScale = useXRWandPanelSettings((state) => state.panelScale)
  const handledRecall = useRef(-1)
  const recallButtonPressed = useRef(false)
  const drag = useRef(new WorkspaceDrag())
  const dragSource = useRef<XRInputSource | null>(null)
  const eye = useRef(new Vector3())
  const viewerMatrix = useRef(new Matrix4())
  const viewerTracked = useRef(false)
  const direction = useRef(new Vector3())
  const target = useRef(new Vector3())
  const localPoint = useRef(new Vector3())
  const localEye = useRef(new Vector3())
  const [tab, setTab] = useState<WorkspaceTab>('build')
  const [dragging, setDragging] = useState(false)

  const endDrag = useCallback(() => {
    const pointerId = drag.current.pointerId
    if (pointerId === null) return
    drag.current.end(pointerId)
    handle.current?.releasePointerCapture?.(pointerId)
    dragSource.current = null
    if (root.current) root.current.userData.dragging = false
    setDragging(false)
  }, [])

  useEffect(() => endDrag(), [endDrag, playerMode])

  useEffect(() => {
    const endSelection = (event: XRInputSourceEvent) => {
      if (event.inputSource === dragSource.current) endDrag()
    }
    const visibilityChanged = () => {
      if (session?.visibilityState !== 'visible') endDrag()
    }
    session?.addEventListener('selectend', endSelection)
    session?.addEventListener('end', endDrag)
    session?.addEventListener('visibilitychange', visibilityChanged)
    return () => {
      session?.removeEventListener('selectend', endSelection)
      session?.removeEventListener('end', endDrag)
      session?.removeEventListener('visibilitychange', visibilityChanged)
      endDrag()
    }
  }, [endDrag, session])

  useFrame((_, __, frame) => {
    const group = root.current
    if (!group) return
    // The host renderer reparents its stereo camera during rendering. Read the
    // XR viewer pose directly so event handlers never apply the origin twice.
    if (session) {
      const pose = frame && referenceSpace && frame.getViewerPose(referenceSpace)
      viewerTracked.current = !!pose && !!origin
      if (!pose || !origin) {
        endDrag()
        return
      }
      origin.updateWorldMatrix(true, false)
      viewerMatrix.current.fromArray(pose.transform.matrix).premultiply(origin.matrixWorld)
      eye.current.setFromMatrixPosition(viewerMatrix.current)
      direction.current.set(0, 0, -1).transformDirection(viewerMatrix.current)
    } else {
      camera.getWorldPosition(eye.current)
      camera.getWorldDirection(direction.current)
      viewerTracked.current = true
    }
    const pressed = isQuestYPressed(controller)
    if (pressed && !recallButtonPressed.current) useXRWorkspace.getState().recall()
    recallButtonPressed.current = pressed

    const source = dragSource.current
    if (
      drag.current.pointerId !== null &&
      source &&
      (!session ||
        !Array.from(session.inputSources).includes(source) ||
        (frame && referenceSpace && !frame.getPose(source.targetRaySpace, referenceSpace)))
    )
      endDrag()

    // Read the store here so controller recall and pointer recall share one path.
    const request = useXRWorkspace.getState().recallRequest
    if (handledRecall.current === request || drag.current.pointerId !== null) return
    // Wait for an actual XR frame before initial placement.
    if (session && !frame) return
    placeWorkspace(eye.current, direction.current, target.current)
    workspaceParentPoint(group, target.current, group.position)
    group.updateWorldMatrix(true, false)
    group.getWorldPosition(target.current)
    target.current.set(eye.current.x, target.current.y, eye.current.z)
    group.lookAt(target.current)
    group.visible = true
    handledRecall.current = request
  }, -55)

  const startDrag = (event: PointerDownEvent) => {
    event.stopPropagation()
    if (
      !viewerTracked.current ||
      !root.current ||
      !drag.current.start(
        event.pointerId,
        workspaceParentPoint(root.current, event.point, localPoint.current),
        root.current.position,
      )
    )
      return
    event.object.setPointerCapture?.(event.pointerId)
    root.current.userData.dragging = true
    if ('pointerState' in event && isXRInputSourceState(event.pointerState)) {
      dragSource.current = event.pointerState.inputSource
    }
    setDragging(true)
  }

  const moveDrag = (event: PointerDownEvent) => {
    event.stopPropagation()
    if (!root.current || !viewerTracked.current) return
    workspaceParentPoint(root.current, event.point, localPoint.current)
    workspaceParentPoint(root.current, eye.current, localEye.current)
    if (
      drag.current.move(
        event.pointerId,
        localPoint.current,
        localEye.current,
        target.current,
      )
    ) {
      root.current.position.copy(target.current)
    }
  }

  const finishDrag = (event: PointerDownEvent) => {
    event.stopPropagation()
    if (drag.current.pointerId === event.pointerId) endDrag()
  }

  return (
    <group
      ref={root}
      name={XR_WAND_PANEL_INPUT_NAME}
      visible={false}
      pointerEventsOrder={100}
      pointerEventsType={(pointerId, pointerType) =>
        pointerType !== 'grab' &&
        (drag.current.pointerId === null || drag.current.pointerId === pointerId)
      }
    >
      <group scale={WORKSPACE_CONTENT_SCALE * panelScale}>
        <group name="xr-workspace-content">
          <PanelFace width={1.32} height={0.92} />
          {tab === 'paint' && <XRWandPaintPanel adapter={adapter} />}
          {tab === 'build' && <XRWandBuildPanel adapter={adapter} />}
          {tab === 'settings' && <XRWandSettingsPanel adapter={adapter} />}
        </group>
        <group name="xr-workspace-tool-rail" position={[-0.75, 0.04, 0]}>
          <PanelFace width={0.16} height={0.7} />
          {TABS.map((value, index) => (
            <RailButton
              key={value}
              icon={value}
              name={`xr-workspace-tab-${value}`}
              y={0.2 - index * 0.125}
              selected={tab === value}
              onClick={() => setTab(value)}
            />
          ))}
          <RailButton
            icon="center"
            name="xr-workspace-recenter"
            y={-0.22}
            onClick={() => useXRWorkspace.getState().recall()}
          />
        </group>
        <mesh layers={overlay} position={[-0.18, -0.535, 0]} raycast={() => null}>
          <sphereGeometry args={[0.022, 16, 10]} />
          <meshBasicMaterial color={XR_WAND_THEME.muted} />
        </mesh>
        <mesh
          ref={handle}
          name="xr-workspace-drag-handle"
          layers={overlay}
          position={[0.075, -0.535, 0]}
          onPointerDown={startDrag}
          onPointerMove={moveDrag}
          onPointerUp={finishDrag}
          onPointerCancel={finishDrag}
          onClick={(event) => event.stopPropagation()}
        >
          <planeGeometry args={[0.52, 0.11]} />
          <meshBasicMaterial depthWrite={false} opacity={0} transparent />
          <mesh rotation={[0, 0, Math.PI / 2]} raycast={() => null}>
            <capsuleGeometry args={[0.022, 0.36, 6, 16]} />
            <meshBasicMaterial color={dragging ? XR_WAND_THEME.accent : XR_WAND_THEME.border} />
          </mesh>
        </mesh>
      </group>
    </group>
  )
}
