'use client'

import { useFrame, useThree, type ThreeEvent } from '@react-three/fiber'
import { isXRInputSourceState, useXR, useXRInputSourceState } from '@react-three/xr'
import { useCallback, useEffect, useRef, useState } from 'react'
import { type Group, Matrix4, type Mesh, Vector3 } from 'three'
import { useWebXRSceneLayers } from '../layers'
import { useXRPlayerMode } from '../mode-switching/store/player-mode'
import type { XRWandAdapter } from './adapter'
import { XRWandBuildPanel } from './build-panel'
import { XRWandPaintPanel } from './paint-panel'
import { XR_WAND_PANEL_INPUT_NAME } from './panel-layout'
import { useXRWandPanelSettings } from './panel-settings'
import { XRWandSettingsPanel } from './settings-panel'
import { PanelFace, SpatialButton } from './spatial-controls'
import { SpatialText } from './spatial-text'
import { XR_WAND_THEME } from './theme'
import {
  constrainWorkspacePosition,
  placeWorkspace,
  WORKSPACE_CONTENT_SCALE,
  WorkspaceDrag,
} from './workspace-placement'
import { useXRWorkspace } from './workspace-store'

type PointerDownEvent = ThreeEvent<PointerEvent>
type WorkspaceTab = 'paint' | 'build' | 'settings'
const TABS = ['paint', 'build', 'settings'] as const

function DockButton({
  label,
  name,
  x,
  y,
  width = 0.23,
  selected,
  onClick,
}: {
  label: string
  name: string
  x: number
  y: number
  width?: number
  selected?: boolean
  onClick: () => void
}) {
  return (
    <SpatialButton
      name={name}
      onClick={onClick}
      position={[x, y, 0]}
      selected={selected}
      size={[width, 0.075]}
    >
      <SpatialText color={XR_WAND_THEME.text} fontSize={0.024} position={[0, 0, 0.012]}>
        {label}
      </SpatialText>
    </SpatialButton>
  )
}

export function XRFloatingWorkspace({ adapter }: { adapter: XRWandAdapter }) {
  const root = useRef<Group>(null)
  const handle = useRef<Mesh>(null)
  const camera = useThree((state) => state.camera)
  const session = useXR((state) => state.session)
  const referenceSpace = useXR((state) => state.originReferenceSpace)
  const origin = useXR((state) => state.origin)
  const playerMode = useXRPlayerMode((state) => state.mode)
  const controller = useXRInputSourceState('controller', 'left')
  const { overlay } = useWebXRSceneLayers()
  const panelScale = useXRWandPanelSettings((state) => state.panelScale)
  const handledRecall = useRef(-1)
  const xPressed = useRef(false)
  const drag = useRef(new WorkspaceDrag())
  const dragSource = useRef<XRInputSource | null>(null)
  const eye = useRef(new Vector3())
  const viewerMatrix = useRef(new Matrix4())
  const viewerTracked = useRef(false)
  const direction = useRef(new Vector3())
  const target = useRef(new Vector3())
  const [tab, setTab] = useState<WorkspaceTab>('build')
  const [collapsed, setCollapsed] = useState(false)
  const [dragging, setDragging] = useState(false)

  const endDrag = useCallback(() => {
    const pointerId = drag.current.pointerId
    if (pointerId === null) return
    drag.current.end(pointerId)
    handle.current?.releasePointerCapture?.(pointerId)
    dragSource.current = null
    if (root.current) root.current.userData.dragging = false
    setDragging(false)
  }, [])

  useEffect(() => endDrag(), [endDrag, playerMode])

  useEffect(() => {
    const endSelection = (event: XRInputSourceEvent) => {
      if (event.inputSource === dragSource.current) endDrag()
    }
    const visibilityChanged = () => {
      if (session?.visibilityState !== 'visible') endDrag()
    }
    session?.addEventListener('selectend', endSelection)
    session?.addEventListener('end', endDrag)
    session?.addEventListener('visibilitychange', visibilityChanged)
    return () => {
      session?.removeEventListener('selectend', endSelection)
      session?.removeEventListener('end', endDrag)
      session?.removeEventListener('visibilitychange', visibilityChanged)
      endDrag()
    }
  }, [endDrag, session])

  useFrame((_, __, frame) => {
    const group = root.current
    if (!group) return
    // The host renderer reparents its stereo camera during rendering. Read the
    // XR viewer pose directly so event handlers never apply the origin twice.
    if (session) {
      const pose = frame && referenceSpace && frame.getViewerPose(referenceSpace)
      viewerTracked.current = !!pose && !!origin
      if (!pose || !origin) {
        endDrag()
        return
      }
      origin.updateWorldMatrix(true, false)
      viewerMatrix.current.fromArray(pose.transform.matrix).premultiply(origin.matrixWorld)
      eye.current.setFromMatrixPosition(viewerMatrix.current)
      direction.current.set(0, 0, -1).transformDirection(viewerMatrix.current)
    } else {
      camera.getWorldPosition(eye.current)
      camera.getWorldDirection(direction.current)
      viewerTracked.current = true
    }
    const pressed =
      controller?.gamepad?.['x-button']?.state === 'pressed' ||
      controller?.inputSource.gamepad?.buttons[4]?.pressed === true
    if (pressed && !xPressed.current) useXRWorkspace.getState().recall()
    xPressed.current = pressed

    const source = dragSource.current
    if (
      drag.current.pointerId !== null &&
      (!handle.current?.hasPointerCapture?.(drag.current.pointerId) ||
        (source &&
          (!session ||
            !Array.from(session.inputSources).includes(source) ||
            (frame && referenceSpace && !frame.getPose(source.targetRaySpace, referenceSpace)))))
    )
      endDrag()

    // Read the store here so controller recall and pointer recall share one path.
    const request = useXRWorkspace.getState().recallRequest
    if (handledRecall.current === request || drag.current.pointerId !== null) return
    // Wait for an actual XR frame before initial placement.
    if (session && !frame) return
    placeWorkspace(eye.current, direction.current, group.position)
    group.rotation.set(
      0,
      Math.atan2(eye.current.x - group.position.x, eye.current.z - group.position.z),
      0,
    )
    group.visible = true
    handledRecall.current = request
    setCollapsed(false)
  }, -55)

  const startDrag = (event: PointerDownEvent) => {
    event.stopPropagation()
    if (
      !viewerTracked.current ||
      !root.current ||
      !drag.current.start(event.pointerId, event.point, root.current.position)
    )
      return
    event.object.setPointerCapture?.(event.pointerId)
    root.current.userData.dragging = true
    if ('pointerState' in event && isXRInputSourceState(event.pointerState)) {
      dragSource.current = event.pointerState.inputSource
    }
    setDragging(true)
  }

  const moveDrag = (event: PointerDownEvent) => {
    event.stopPropagation()
    if (!root.current || !viewerTracked.current) return
    if (drag.current.move(event.pointerId, event.point, eye.current, target.current)) {
      root.current.position.copy(target.current)
    }
  }

  const finishDrag = (event: PointerDownEvent) => {
    event.stopPropagation()
    if (drag.current.pointerId === event.pointerId) endDrag()
  }

  const changeDistance = (amount: number) => {
    if (!root.current || dragging || !viewerTracked.current) return
    direction.current.copy(root.current.position).sub(eye.current).normalize()
    target.current.copy(root.current.position).addScaledVector(direction.current, amount)
    if (constrainWorkspacePosition(target.current, eye.current))
      root.current.position.copy(target.current)
  }

  return (
    <group
      ref={root}
      name={XR_WAND_PANEL_INPUT_NAME}
      visible={false}
      pointerEventsOrder={100}
      pointerEventsType={(pointerId, pointerType) =>
        pointerType !== 'grab' &&
        (drag.current.pointerId === null || drag.current.pointerId === pointerId)
      }
    >
      <group scale={WORKSPACE_CONTENT_SCALE * panelScale}>
        {!collapsed && (
          <group name="xr-workspace-content">
            <PanelFace />
            {tab === 'paint' && <XRWandPaintPanel adapter={adapter} />}
            {tab === 'build' && <XRWandBuildPanel adapter={adapter} />}
            {tab === 'settings' && <XRWandSettingsPanel adapter={adapter} />}
          </group>
        )}
        <group position={[0, -0.7, 0]}>
          <PanelFace width={0.9} height={0.3} />
          {TABS.map((value, index) => (
            <DockButton
              key={value}
              label={value.charAt(0).toUpperCase() + value.slice(1)}
              name={`xr-workspace-tab-${value}`}
              x={(index - 1) * 0.29}
              y={0.095}
              width={0.27}
              selected={!collapsed && tab === value}
              onClick={() => {
                setTab(value)
                setCollapsed(false)
              }}
            />
          ))}
          <DockButton
            label="Recenter"
            name="xr-workspace-recenter"
            x={-0.29}
            y={0}
            onClick={() => useXRWorkspace.getState().recall()}
          />
          <DockButton
            label={collapsed ? 'Expand' : 'Collapse'}
            name="xr-workspace-collapse"
            x={0}
            y={0}
            onClick={() => setCollapsed((value) => !value)}
          />
          <DockButton
            label="Size −"
            name="xr-workspace-smaller"
            x={0.215}
            y={0}
            width={0.13}
            onClick={() => useXRWandPanelSettings.getState().setPanelScale(panelScale - 0.1)}
          />
          <DockButton
            label="Size +"
            name="xr-workspace-larger"
            x={0.365}
            y={0}
            width={0.13}
            onClick={() => useXRWandPanelSettings.getState().setPanelScale(panelScale + 0.1)}
          />
          <DockButton
            label="Nearer"
            name="xr-workspace-nearer"
            x={-0.29}
            y={-0.095}
            onClick={() => changeDistance(-0.15)}
          />
          <DockButton
            label="Farther"
            name="xr-workspace-farther"
            x={0}
            y={-0.095}
            onClick={() => changeDistance(0.15)}
          />
          <SpatialText
            fontSize={0.018}
            color={XR_WAND_THEME.muted}
            position={[0.29, -0.095, 0.012]}
          >
            X / Menu: recall
          </SpatialText>
        </group>
        <mesh
          ref={handle}
          name="xr-workspace-drag-handle"
          layers={overlay}
          position={[0, -0.9, 0]}
          onPointerDown={startDrag}
          onPointerMove={moveDrag}
          onPointerUp={finishDrag}
          onPointerCancel={finishDrag}
          onClick={(event) => event.stopPropagation()}
        >
          <boxGeometry args={[0.38, 0.065, 0.025]} />
          <meshBasicMaterial color={dragging ? XR_WAND_THEME.accent : XR_WAND_THEME.border} />
        </mesh>
        <SpatialText fontSize={0.02} color={XR_WAND_THEME.text} position={[0, -0.9, 0.017]}>
          {dragging ? 'Moving' : 'Drag to move'}
        </SpatialText>
      </group>
    </group>
  )
}
