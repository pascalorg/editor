'use client'

import { useXRInputSourceStateContext, XRSpace } from '@react-three/xr'
import { XR_WAND_PANEL_LAYOUT } from './panel-layout'
import { SpatialButton } from './spatial-controls'
import { SpatialText } from './spatial-text'
import { XR_WAND_THEME } from './theme'
import { useXRWorkspace } from './workspace-store'

export function XRWorkspaceLauncher({ type }: { type: 'controller' | 'hand' }) {
  const state = useXRInputSourceStateContext(type)
  if (state.inputSource.handedness !== 'left') return null
  const hand = type === 'hand'
  return (
    <XRSpace space={hand ? XR_WAND_PANEL_LAYOUT.attachment.handSpace : 'grip-space'}>
      <group
        position={hand ? XR_WAND_PANEL_LAYOUT.attachment.handPosition : [0, 0, -0.085]}
        rotation={hand ? XR_WAND_PANEL_LAYOUT.attachment.handRotation : [0, 0, 0]}
      >
        <group
          name="xr-workspace-launcher"
          position={[0, 0.025, 0]}
          rotation={[-Math.PI / 2, 0, 0]}
          pointerEventsOrder={101}
          pointerEventsType={{ deny: 'grab' }}
        >
          <SpatialButton
            name="xr-workspace-summon"
            position={[0, 0, 0]}
            size={[0.065, 0.035]}
            selected
            onClick={() => useXRWorkspace.getState().recall()}
          >
            <SpatialText color={XR_WAND_THEME.text} fontSize={0.012} position={[0, 0, 0.012]}>
              Menu
            </SpatialText>
          </SpatialButton>
        </group>
      </group>
    </XRSpace>
  )
}
